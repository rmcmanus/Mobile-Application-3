/** Automatically generated file. DO NOT MODIFY */
package edu.mines.rmcmanus.dhunter.applicationthree;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}